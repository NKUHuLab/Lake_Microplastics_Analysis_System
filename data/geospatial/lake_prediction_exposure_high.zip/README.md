# Selected lake polygons

7,161 lakes; WGS84 geographic coordinates. Keep .shp, .shx, .dbf, .prj and .cpg together. See field_dictionary.csv for attributes and selection.json for counts.

Selection: frozen High model-reliability class; no known invalid area-ratio lake flag; exact coordinate and prediction match to the selected uncertainty table; valid geometry. This subset does not repair or reproduce the full area-overlap sensitivity analysis. Range-derived exposure is potential co-occurrence.

HydroLAKES geometry: CC BY 4.0, Messager et al. (2016), https://doi.org/10.1038/ncomms13603, https://www.hydrosheds.org/products/hydrolakes . Exposure attributes acknowledge the IUCN Red List and remain subject to applicable non-commercial/source conditions: https://nrl.iucnredlist.org/about/faqs . No raw IUCN range polygons or IUCN endorsement are included. See the repository data/README.md for full scope and attribution.

The former unc_pval attribute has been removed because a t test treating forest trees as independent observations is not valid. Retained predictions, reliability classes, exposure scores and polygon geometry are unchanged.
